import React from 'react';
import './footer.css';

function Footer(){
    return(
        <>  
            <footer className= "container-fluid footer text-small">
                © Copyleft 2020 Corso Front-End Developer Tree School
            </footer>
        </>
    )
}
export default Footer;