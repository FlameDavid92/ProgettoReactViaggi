import React from 'react'
const contesto = React.createContext()
export default contesto