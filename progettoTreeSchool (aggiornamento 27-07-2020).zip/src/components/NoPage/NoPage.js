import React from 'react';

export default function NoPage(){
    return(<>NoPage</>)
}