import React from 'react';

export default function Note() {
    return (
        <div className="row">
            <div className="col-10 offset-1">
                <ul>
                    <li className="text-medium">Nessuna nota disponibile</li>
                </ul>
            </div>
        </div>
    )
}